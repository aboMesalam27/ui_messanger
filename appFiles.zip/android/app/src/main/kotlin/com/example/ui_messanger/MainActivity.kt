package com.example.ui_messanger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
