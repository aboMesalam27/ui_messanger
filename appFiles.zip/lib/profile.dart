import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        backgroundColor: Colors.white,
        title: Text(
          "Me",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(top: 50.0),
          child: Column(
            children: [
              CircleAvatar(
                radius: 60,
                backgroundImage: NetworkImage(
                    "https://scontent.fcai21-4.fna.fbcdn.net/v/t1.6435-9/138583070_851257162333980_3936517221826063000_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=xf18aNK-YP0AX9FycUS&_nc_ht=scontent.fcai21-4.fna&oh=64fb3d4a86d9df9f6ca9ae190d9b35cf&oe=6153EF76"),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Abdelrhman Abo Mesalam",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),
              ),
              //ListWheelScrollView.useDelegate(itemExtent: 75, childDelegate,)
            ],
          ),
        ),
      ),
    );
  }
}
